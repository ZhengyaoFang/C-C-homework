#include <stdio.h>
#include <stdlib.h>

//�ɶ���++
#define OK 1

typedef int Status;

/**********************************ͨ��***************************/
Status GetInt(int *a,int *b);
Status GetOrder(int *a);


/**********************************����***************************/
